import React from 'react'

const Wrapper = (props) => {
  return (
    <>
        {props.children}
    </>
  )
}

export default Wrapper