import React from 'react'
import './style.css'

const PageLoader = () => {
    return (
        <div id="loader-container">
    <div className="loader"></div>
</div>
    )
}

export default PageLoader