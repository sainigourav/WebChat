export const initialState = {
    token: '',
    userId: '',
    email: '',
    profilePic: '',
    name: '',
    error: null,
    loading: false
}