declare module "*.jpeg" {
    const value: any;
    export default value;
  }
  