declare module "*.jpg" {
    const value: any;
    export default value;
  }
  