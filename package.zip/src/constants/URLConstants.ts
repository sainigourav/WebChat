const URLConstants = {
    Authenticate: '/user/authenticate',
    GetContact: '/user/getContact',
    SignUp: '/user/signUp',
}

export default URLConstants;